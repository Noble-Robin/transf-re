from django.apps import AppConfig

class CaplogyAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'caplogy_app'
